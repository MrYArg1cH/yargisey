<script setup>
const colorMode = useColorMode()

const changeValue = () => {
  currentValue.value = currentValue.value < 3 ? currentValue.value + 1 : 1;
};

const currentValue = ref(1);

onMounted( async () => {
    const interval = setInterval(changeValue, 5000);

    onBeforeUnmount(() => {
    clearInterval(interval);
});
});

function redirect(url) {
    window.open(url)
}
</script>

<template>

<div class="dark:bg-zinc-900 bg-white flex flex-col pt-32 general-animation">
        <div class="from-white to-zinc-300/50 dark:from-zinc-900  dark:to-zinc-700/30 bg-gradient-to-b">
            <div class="flex flex-col justify-center max-w-7xl mx-auto p-16 lg:py-[156px] lg:px-4">
                <div class="grid grid-rows-2 grid-cols-1 lg:grid-rows-1 lg:grid-cols-2 gap-8">
                    <div class="flex flex-col justify-start items-center text-center lg:items-start lg:text-left gap-10">

                        <div>
                            <h1 v-if="currentValue === 1" class="revhomeanim text-4xl font-bold font-[Comfortaa] text-zinc-900 dark:text-zinc-100 lg:text-5xl">
                                <span class="block">Лучшие разработчики</span>
                            </h1>

                            <h1 v-if="currentValue === 2" class="revhomeanim text-4xl font-bold font-[Comfortaa] text-zinc-900 dark:text-zinc-100 lg:text-5xl">
                                <span class="block">Адекватная цена</span>
                            </h1>

                            <h1 v-if="currentValue === 3" class="revhomeanim text-4xl font-bold font-[Comfortaa] text-zinc-900 dark:text-zinc-100 lg:text-5xl">
                                <span class="block">Быстрое выполнение</span>
                            </h1>
                        </div>

                        <div class="flex flex-col gap-4">
                            <p class="text-lg text-zinc-700 dark:text-zinc-300 lg:text-xl font-[Comfortaa]">
                                Это всё про Yargisey!
                            </p>
                            <p class="text-lg text-zinc-700 dark:text-zinc-300 lg:text-xl font-[Comfortaa]">
                                Мы пишем фронтенд, Discord ботов на JS и Python, ПО на Java И Python и многое ещё другого!
                            </p>

                            <div>
                                <button @click="redirect('https://discord.com/invite/yargisey')" class="mt-8 rounded-xl bg-zinc-100 border-2 border-zinc-200 dark:bg-zinc-800 dark:border-zinc-700 hover:bg-zinc-700 hover:dark:bg-zinc-100 hover:text-zinc-200 hover:dark:text-zinc-600 px-4 py-2 flex gap-2 items-center transition font-[Comfortaa] text-zinc-600 dark:text-zinc-200">
                                    <UiIcon size="22px" name="headphones" />
                                    Связаться с нами
                                </button>
                            </div>
                        </div>

                    </div>

                    <div class="flex flex-col justify-center items-center text-center lg:items-center lg:text-center gap-10">
                        <div v-if="colorMode.unknown"></div>
                        <img v-else-if="colorMode.value ==='light'" src="../assets/logo.png" class="appear-animation w-64 h-64" />
                        <img v-else-if="colorMode.value ==='dark'" src="../assets/logo_white.png" class="appear-animation w-64 h-64" />
                    </div>
                </div>
            </div>
        </div>

        <div id="we" class="from-white to-zinc-300/50 dark:from-zinc-900  dark:to-zinc-700/30 bg-gradient-to-t">
            <div class="flex flex-col justify-center max-w-7xl mx-auto p-16 lg:py-[96px] lg:px-4">
                <div class="grid gap-16">

                    <div class="flex flex-col justify-center items-center text-center gap-10">

                        <UiIcon class="text-zinc-800 dark:text-zinc-200 shrink-0 pr-2.5" size="48px" name="info-circle" />

                        <div>

                            <h1 class="flex gap-8 items-center text-4xl font-bold font-[Comfortaa] text-zinc-900 dark:text-zinc-100 lg:text-5xl">
                                <span class="block">О нашей команде</span>
                            </h1>
                        </div>

                        <div class="flex flex-col gap-4">
                            <p class="text-lg text-zinc-700 dark:text-zinc-300 lg:text-xl font-[Comfortaa]">
                                Добро пожаловать в мир технологий и инноваций! Наша команда разработчиков ПО - это творческий коллектив, влюбленный в мир кода и создания уникальных решений. Мы с гордостью представляем вам наши профессиональные умения в сфере разработки программного обеспечения. Идея была одного человека с имени Алексей, а реализовал человек с именем Ярослав (MrYArg1cH)
                            </p>
                        </div>

                    </div>
                </div>
            </div>
        </div>

        <div id="do" class="bg-white dark:bg-zinc-900">
            <div class="flex flex-col justify-center max-w-7xl mx-auto p-16 lg:py-[96px] lg:px-4">
                <div class="grid gap-16">

                    <div class="flex flex-col justify-center items-center text-center gap-10">

                        <UiIcon class="text-zinc-800 dark:text-zinc-200 shrink-0 pr-2.5" size="48px" name="device-laptop" />

                        <div>
                            <h1 class="flex gap-8 items-center text-4xl font-bold font-[Comfortaa] text-zinc-900 dark:text-zinc-100 lg:text-5xl">
                                <span class="block">Чем мы занимаемся?</span>
                            </h1>
                        </div>

                        <div class="flex flex-col gap-4">
                            <p class="text-lg text-zinc-700 dark:text-zinc-300 lg:text-xl font-[Comfortaa]">
                                Мы специализируемся на создании мини-сайтов, работая исключительно с FrontEnd-технологиями для того, чтобы ваш веб-проект выглядел современно и привлекательно. Наша команда также охватывает область разработки программного обеспечения на Python и Java, а также создание интеллектуальных и многофункциональных Дискорд ботов на JS и Python.
                            </p>
                        </div>

                    </div>
                </div>
            </div>
        </div>

        <div id="staff" class="from-white to-zinc-300/50 dark:from-zinc-900  dark:to-zinc-700/30 bg-gradient-to-b">
            <div class="flex flex-col justify-center max-w-7xl mx-auto p-16 lg:py-[96px] lg:px-4">
                <div class="grid gap-16">

                    <div class="flex flex-col justify-center items-center text-center gap-10">

                        <UiIcon class="flex xl:hidden text-zinc-800 dark:text-zinc-200 shrink-0 pr-2.5" size="42px" name="users" />

                        <div>
                            <h1 class="flex gap-8 items-center text-4xl font-bold font-[Comfortaa] text-zinc-900 dark:text-zinc-100 lg:text-5xl">
                                <span class="block">Персонал</span>
                                <UiIcon class="hidden xl:flex text-zinc-800 dark:text-zinc-200 shrink-0 pr-2.5" size="42px" name="users" />
                            </h1>
                        </div>

                        <div class="flex flex-col lg:grid lg:grid-cols-3 gap-12 lg:justify-center overflow-x-auto -mx-4 px-4">
                            <div class="flex flex-col items-center gap-6">
                                <img src="../assets/avatars/yaroslav.png" class="w-32 h-32 rounded-full" />
                                <p class="text-2xl text-zinc-700 dark:text-zinc-300 font-semibold font-[Comfortaa]">Ярослав</p>
                                <p class="text-lg text-zinc-700 dark:text-zinc-300 font-[Comfortaa]">Директор</p>
                            </div>
                            <div class="flex flex-col items-center gap-6">
                                <img src="../assets/avatars/alex.png" class="w-32 h-32 rounded-full" />
                                <p class="text-2xl text-zinc-700 dark:text-zinc-300 font-semibold font-[Comfortaa]">Алексей</p>
                                <p class="text-lg text-zinc-700 dark:text-zinc-300 font-[Comfortaa]">Ген. Директор</p>
                            </div>
                            <div class="flex flex-col items-center gap-6">
                                <img src="../assets/avatars/platon.png" class="w-32 h-32 rounded-full" />
                                <p class="text-2xl text-zinc-700 dark:text-zinc-300 font-semibold font-[Comfortaa]">Платон</p>
                                <p class="text-lg text-zinc-700 dark:text-zinc-300 font-[Comfortaa]">Тех. Поддержка</p>
                            </div>
                        </div>

                        

                    </div>
                </div>
            </div>
        </div>

        <div id="faq" class="bg-zinc-300/50 dark:bg-zinc-700/30">
            <div class="flex flex-col justify-center max-w-7xl mx-auto p-16 lg:py-[96px] lg:px-4">
                <div class="grid gap-16">

                    <div class="flex flex-col justify-center items-center text-center gap-10">

                        <UiIcon class="flex xl:hidden text-zinc-800 dark:text-zinc-200 shrink-0 pr-2.5" size="42px" name="question-circle" />

                        <div>
                            <h1 class="flex gap-8 items-center text-4xl font-bold font-[Comfortaa] text-zinc-900 dark:text-zinc-100 lg:text-5xl">
                                <span class="block">Часто задаваемые вопросы</span>
                                <UiIcon class="hidden xl:flex text-zinc-800 dark:text-zinc-200 shrink-0 pr-2.5" size="42px" name="question-circle" />
                            </h1>
                        </div>

                        <div class="flex flex-col gap-12">
                            <div class="flex flex-col gap-2">
                                <h2 class="text-2xl font-semibold font-[Comfortaa] text-zinc-700 dark:text-zinc-300">Можно на данный момент делать заказы?</h2>
                                <p class="text-lg text-zinc-700 dark:text-zinc-300 font-[Comfortaa]">Нет, к сожалению, в данный момент мы не принимаем новые заказы.</p>
                            </div>
                            <div class="flex flex-col gap-2">
                                <h2 class="text-2xl font-semibold font-[Comfortaa] text-zinc-700 dark:text-zinc-300">Где находится вся информация?</h2>
                                <p class="text-lg text-zinc-700 dark:text-zinc-300 font-[Comfortaa]">
                                    Вся необходимая информация доступна на нашем 
                                    <span @click="redirect('https://discord.com/invite/yargisey')" class="underline underline-offset-2 cursor-pointer transition text-zinc-500 dark:text-zinc-200 hover:text-zinc-600 hover:dark:text-zinc-300 active:text-zinc-700 active:dark:text-zinc-400">Discord сервере</span>.
                                    Загляните туда, чтобы быть в курсе последних обновлений и общаться с нашей замечательной командой.
                                    Если у вас есть дополнительные вопросы, не стесняйтесь обращаться!
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
</div>

</template>