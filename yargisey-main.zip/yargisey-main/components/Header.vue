<script setup>
// Цветовая тема

const colorMode = useColorMode()

function changeLight() {
  colorMode.preference = 'light'
  const htmlElement = document.querySelector('html');
  if (htmlElement) {
    htmlElement.style.backgroundColor = '#fefefe';
  }
}

function changeDark() {
  colorMode.preference = 'dark'
  const htmlElement = document.querySelector('html');
  if (htmlElement) {
    htmlElement.style.backgroundColor = '#171717';
  }
}

// Прозрачность навбара в зависимости от прокрутки

const navbarColor = ref('standart');

const updateNavbarColor = () => {
  const scrollPosition = window.scrollY;
  if (scrollPosition > 50) {
    navbarColor.value = 'changed'; // Изменяем цвет навбара при достижении определенной позиции прокрутки
  } else {
    navbarColor.value = 'standart'; // Возвращаем изначальный цвет навбара
  }
};


onMounted(async () => {
  window.addEventListener('scroll', updateNavbarColor);
});

onUnmounted(() => {
  window.removeEventListener('scroll', updateNavbarColor);
});

function redirect(url) {
    window.open(url)
}

const router = useRouter();

const scrollToSection = (section) => {
  router.push({ hash: `#${section}` });
};
</script>

<template>
   <header :class="{ 'bg-white/25 border-zinc-200/50 backdrop-blur backdrop-saturate-150 border-b': $colorMode.value === 'light', 'bg-zinc-900/15 dark:border-zinc-800/50 backdrop-blur backdrop-saturate-150 border-b': $colorMode.value === 'dark', 'bg-transparent border-transparent dark:bg-transparent dark:border-transparent': $colorMode.unknown }" class="w-full py-6 px-6 fixed top-0 z-50 transition">
      <div class="flex flex-row items-center justify-between max-w-7xl mx-auto">
  
        <NuxtLink to="/" class="logo active:scale-90 cursor-pointer transition flex gap-6 items-center">
            <div v-if="colorMode.unknown"></div>
            <img v-else-if="colorMode.value === 'light'" src="../assets/logo.png" class="appear-animation w-16 h-16" />
            <img v-else-if="colorMode.value === 'dark'" src="../assets/logo_white.png" class="appear-animation w-16 h-16" />
            <h1 class="font-[Comfortaa] font-bold text-2xl text-black dark:text-white">Yargisey</h1>
        </NuxtLink>
  
        <div class="hidden xl:flex flex-row gap-4 items-center center">
          <button @click="scrollToSection('we')" class="grid grid-flow-col font-[Inter] font-medium p-[16px] py-[0.5rem] gap-[2.5] items-center rounded-full no-underline hover:bg-zinc-100 dark:hover:bg-zinc-800 transition" to="/">
            <UiIcon class="text-zinc-600 dark:text-zinc-200 shrink-0 pr-2.5" size="22px" name="info-circle" />
            <p class="text-zinc-600 dark:text-zinc-200 font-[Comfortaa] font-semibold">О нас</p>
          </button>
  
          <button @click="scrollToSection('do')" class="grid grid-flow-col font-[Inter] font-medium p-[16px] py-[0.5rem] gap-[2.5] items-center rounded-full no-underline hover:bg-zinc-100 dark:hover:bg-zinc-800 transition">
            <UiIcon class="text-zinc-600 dark:text-zinc-200 shrink-0 pr-2.5" size="22px" name="device-laptop" />
            <p class="text-zinc-600 dark:text-zinc-200 font-[Comfortaa] font-semibold">Что мы делаем</p>
          </button>

          <button @click="scrollToSection('staff')" class="grid grid-flow-col font-[Inter] font-medium p-[16px] py-[0.5rem] gap-[2.5] items-center rounded-full no-underline hover:bg-zinc-100 dark:hover:bg-zinc-800 transition">
            <UiIcon class="text-zinc-600 dark:text-zinc-200 shrink-0 pr-2.5" size="22px" name="users" />
            <p class="text-zinc-600 dark:text-zinc-200 font-[Comfortaa] font-semibold">Персонал</p>
          </button>
            
          <button @click="scrollToSection('faq')" class="grid grid-flow-col font-[Inter] font-medium p-[16px] py-[0.5rem] gap-[2.5] items-center rounded-full no-underline hover:bg-zinc-100 dark:hover:bg-zinc-800 transition">
            <UiIcon class="text-zinc-600 dark:text-zinc-200 shrink-0 pr-2.5" size="22px" name="help-circle" />
            <p class="text-zinc-600 dark:text-zinc-200 font-[Comfortaa] font-semibold">FAQ</p>
          </button>
        </div>
  
        <div class="flex flex-row items-center gap-4">

            <div v-if="colorMode.unknown"></div>
  
            <button class="appear-animation p-2.5 rounded-full hover:bg-zinc-100 dark:hover:bg-zinc-800 transition cursor-pointer active:scale-90" @click="changeDark()" v-else-if="colorMode.value === 'light'">
                <UiIcon name="sun" size="22px" class="text-zinc-600 dark:text-zinc-200" />
            </button>
  
            <button class="appear-animation p-2.5 rounded-full hover:bg-zinc-100 dark:hover:bg-zinc-800 transition cursor-pointer active:scale-90" @click="changeLight()" v-else-if="colorMode.value === 'dark'">
                <UiIcon name="moon" size="22px" class="text-zinc-600 dark:text-zinc-200" />
            </button>

            <button @click="redirect('https://discord.com/invite/yargisey')" class="hidden xl:grid gap-2.5 grid-flow-col font-[Inter] font-medium p-[16px] py-[0.5rem] items-center rounded-full no-underline hover:bg-zinc-100 dark:hover:bg-zinc-800 transition">
                <UiIcon class="text-zinc-600 dark:text-zinc-200 shrink-0" size="22px" name="headphones" />
                <p class="text-zinc-600 dark:text-zinc-200 font-[Comfortaa] font-semibold">Связаться</p>
            </button>
        </div>
        
      </div>
    </header>
</template>