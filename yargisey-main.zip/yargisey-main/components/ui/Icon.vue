<script setup>

import { icons } from '@iconify-json/tabler';
import { getIconData, iconToSVG, iconToHTML, replaceIDs } from '@iconify/utils';

const props = defineProps({
  name: String,
  size: String,
});

function getIcon(name) {
    const iconName = name;

    const iconData = getIconData(icons, iconName);
        if (!iconData) {
            throw new Error(`Иконка "${iconName}" отсутствует!`);
        }

    const renderData = iconToSVG(iconData, {
        height: 'auto',
    });

    const customSVG = iconToHTML(replaceIDs(renderData.body), renderData.attributes);

    const regex = /width="(\d+)" height="(\d+)"/;

    const modifiedSVG = customSVG.replace(regex, `width="${props.size}" height="${props.size}"`);

    return modifiedSVG
}

</script>

<template>
    <div v-html="getIcon(props.name)"></div>
</template>