<script setup>
const colorMode = useColorMode()

function getCurrentYear() {
    return new Date().getFullYear()
}

function redirect(url) {
    window.open(url)
}
</script>

<template>
<div class="dark:bg-zinc-900 bg-white">
<footer class="p-10 xl:p-16 bg-zinc-300/50 dark:bg-zinc-700/30">
       <div class="max-w-7xl mx-auto flex flex-col xl:flex-row gap-8 xl:justify-center xl:text-center xl:items-center">
          <div class="flex flex-col gap-3 max-w-xl">
             <div class="xl:flex grid gap-4 xl:justify-center items-center">
                <div v-if="colorMode.unknown"></div>
                <img v-else-if="colorMode.value === 'light'" src="../assets/logo.png" class="appear-animation w-16 h-16" />
                <img v-else-if="colorMode.value === 'dark'" src="../assets/logo_white.png" class="appear-animation w-16 h-16" />
                <h1 class="font-[Comfortaa] font-bold text-2xl text-black dark:text-white">Yargisey</h1>
             </div>
             <p class="font-[Comfortaa] text-zinc-600 dark:text-zinc-200">© {{ getCurrentYear() }} yargisey</p>
             <p class="font-[Comfortaa] text-zinc-600 dark:text-zinc-200">Веб-сайт сделан <span @click="redirect('https://t.me/GGSkyOne')" class="underline underline-offset-2 cursor-pointer transition text-zinc-500 dark:text-zinc-200 hover:text-zinc-600 hover:dark:text-zinc-300 active:text-zinc-700 active:dark:text-zinc-400">@GGSkyOne</span>.</p>
          </div>

       </div>
    </footer>
</div>
</template>